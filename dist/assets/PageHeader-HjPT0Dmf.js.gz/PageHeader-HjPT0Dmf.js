import"./animations-CUSsutLB.js";import{P as i}from"./index-CU536pqR.js";i.string.isRequired,i.string,i.string,i.string,i.oneOf(["left","center","right"]);
